CC == combined components

CR == combined reference (e.g PSD subevent)
