
Presentations:

[Ion Vidyo 25.04.2019](https://indico.cern.ch/event/813662/contributions/3401813/attachments/1834175/3004499/20190425_AnalysisIon.pdf)
[Ion Vidyo 09.05.2019](https://indico.cern.ch/event/816515/contributions/3408416/attachments/1841474/3019562/20190509_AnalysisIon.pdf)
[Ion Vidyo 23.05.2019](https://indico.cern.ch/event/821693/contributions/3435113/attachments/1849557/3035837/20190523_AnalysisIon_Release.pdf)
[WPCF2019](https://indico.cern.ch/event/808583/contributions/3371746/attachments/1855427/3052731/20190607_WPCF_flow.pdf)


