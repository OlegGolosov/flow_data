Digitized results of the elliptic flow for AuAu @ 4.5GeV (pLAB = 9.8A GeV/c)
from STAR fxt

Sources:

https://indico.gsi.de/event/8242/session/8/contribution/9/material/slides/0.pdf

https://arxiv.org/abs/1807.06738
